package com.infinite.beantest;

import java.util.Date;

import com.infinite.beans.User;

public class BeanTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		User srinj = new User();
		srinj.setUsername("Srinivas");
		srinj.setPassword("SS123@%");
		srinj.setLogindate(new Date());
		srinj.display();
		System.out.println(srinj.getUsername());
	}

}
