package com.infinite.demo.service;

public class TwitterNotificationService {

    public TwitterNotificationService() {
        System.out.println("TwitterNotificationService Constructor");
    }
}
