package com.infinite.demo.service;

public class EmailNotificationService  {

    public EmailNotificationService() {
        System.out.println("EmailNotificationService Constructor");
    }
}