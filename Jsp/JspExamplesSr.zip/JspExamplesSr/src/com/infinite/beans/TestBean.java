package com.infinite.beans;

public class TestBean {

	private String msg = "null";
	
	public String getMsg() {
		return msg;
	}
	
	public void setMsg(String msg) {
		this.msg = msg;
	}
}
