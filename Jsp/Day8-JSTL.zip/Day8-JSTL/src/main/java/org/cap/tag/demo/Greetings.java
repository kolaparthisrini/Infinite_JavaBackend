package org.cap.tag.demo;

import java.io.IOException;
import java.io.StringWriter;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class Greetings extends SimpleTagSupport {
	
	private String color;
	
	

	public void setColor(String color) {
		this.color = color;
	}



	public String getColor() {
		return color;
	}



	@Override
	public void doTag() throws JspException, IOException {
		
		JspWriter out= getJspContext().getOut();
		
		StringWriter sw=new StringWriter();
		getJspBody().invoke(sw);
		System.out.println(getColor());
		if(getColor()!=null)
		{
			String str="<h1 style='color:"+getColor()+";'>Hello! "+ sw +", Good Afternoon!</h1>";
			
			out.println(str);
		
		}else
			out.println("<h1>Hello! "+ sw +", Good Afternoon!</h1>");
		
		//if(sw!=null || sw.toString()!=null)
			
		/*else
			out.println("<h1>Hello!  Good Afternoon!</h1>");*/
	}

	
	
}
