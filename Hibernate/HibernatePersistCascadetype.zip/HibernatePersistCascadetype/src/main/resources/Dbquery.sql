---- DATABASE CREATION ----
create database if not exists cascadedb;

use cascadedb;