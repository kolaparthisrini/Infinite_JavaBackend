package com.hibernate.impl;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;

import com.hibernate.model.Student;
import com.hibernate.model.Subject;

public class Demoapp {

	public static void main(String[] args) {

		// Creating the configuration instance & passing the hibernate configuration file.
		Configuration config = new Configuration();
		config.configure("hibernate.cfg.xml");

		// Hibernate session object to start the db transaction.
		Session s = config.buildSessionFactory().openSession();

		// Creating the "Student" and "Subject" model objects.
		Student stu1 = new Student();
		stu1.setS_id(101);
		stu1.setName("John sena");
		stu1.setAge(25);

		Subject sub1 = new Subject();
		sub1.setS_id(stu1.getS_id());
		sub1.setName("Sashi Sena");
		sub1.setMarks(100);

		stu1.setSub(sub1);

		// Deleting the data from the database.
		s.getTransaction().begin();

		s.persist(stu1);			// No need to perform the "persist" operation separately for the different entities.

		s.getTransaction().commit();

		// Closing the session object.
		s.close();
	}
}