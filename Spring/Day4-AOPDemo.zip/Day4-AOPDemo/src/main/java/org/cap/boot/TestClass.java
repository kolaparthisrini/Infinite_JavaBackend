package org.cap.boot;

import org.cap.pojo.Account;
import org.cap.service.BankServiceImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestClass {

	public static void main(String[] args) {
		ApplicationContext context=
				new ClassPathXmlApplicationContext("aopBeans.xml");
		
		
		Account account=(Account)context.getBean("account");
		
		BankServiceImpl serviceImpl=(BankServiceImpl) context.getBean("bankService");
	
		//serviceImpl.fundTransfer(account, 3000);
		Account account2=serviceImpl.withdrawal(account,0);
		
		System.out.println("Operation Completed");
	}

}
