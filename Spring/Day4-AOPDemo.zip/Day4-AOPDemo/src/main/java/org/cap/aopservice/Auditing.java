package org.cap.aopservice;

import org.aspectj.lang.ProceedingJoinPoint;
import org.cap.pojo.Account;

public class Auditing {
	
	public void beforeFundTransfer() {
		/*-----------
		----
		----*/
		
		System.out.println("------Before Money Transfer-------");
	}
	
	public void afterFundTransfer() {
		System.out.println("--------After Money Transfer-------");
	}
	
	public void around(ProceedingJoinPoint pjp) throws Throwable {
		
		System.out.println("************Before My BL**********");
		Object[] methodArgs= pjp.getArgs();
		for(Object obj:methodArgs)
			System.out.println(obj);
		Account account=(Account)methodArgs[0];
		account.setBalance(0);
		
	
		methodArgs[0]=account;
		
		pjp.proceed(methodArgs);
		
		System.out.println("************After My BL**********");
	}
	
	
	
	
	public void afterReturning(Account account) {
		System.out.println("Account:" + account);
		System.out.println("************After value Return from BL**********");
	}
	
	
	
	
	public void afterThrow(Exception ex) {
		
		System.out.println("************After Throwing from BL**********");
		System.out.println(ex.getMessage());
	}
	
	
	
	
	
	

}
