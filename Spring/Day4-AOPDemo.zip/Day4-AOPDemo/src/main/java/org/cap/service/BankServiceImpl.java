package org.cap.service;

import org.cap.pojo.Account;

public class BankServiceImpl {
	
	public void fundTransfer(Account account,double amount) {
		double amt=account.getBalance()+amount;
		System.out.println("Amoutn Transfered: " + amt);
	}

	
	public Account withdrawal(Account account,double amt) {
		double amoutn=account.getBalance()-amt;
		account.setBalance(amoutn);

		System.out.println("Update Amount after withdrawal: " + amoutn);
		
		if(amt==0)
			throw new NullPointerException("Hey! Account is Null");
		return account;
	}
}
