package com.infinite.spring.dao;

import com.infinite.spring.model.Aadhar;

public interface IAadharDAO {

	public void aadharinsert(Aadhar adhar);
}
