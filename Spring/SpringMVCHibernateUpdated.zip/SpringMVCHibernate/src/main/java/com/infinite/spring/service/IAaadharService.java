package com.infinite.spring.service;

import com.infinite.spring.model.Aadhar;

public interface IAaadharService {

	
	public  void AaadharInsert(Aadhar aa);
}
