package com.kb.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.kb.model.Customer;

@Controller
public class LoginController {
	
	
	 @RequestMapping(value = "/login", method = RequestMethod.GET)
	    public String viewLoginPage(Model model) {
	      Customer customer = new Customer();
	        model.addAttribute("customer", customer);
	        return "login";
	    }
	
	 @RequestMapping(value = "/doLogin", method = RequestMethod.POST)
	    public String doLogin(@Valid Customer customer, BindingResult result,Model model) {
		 model.addAttribute("customer",customer);
	      if(result.hasErrors()){
	    	  return "login";
	      }
	      
	      return "home";
	    }

}
